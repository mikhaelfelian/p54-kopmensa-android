$(document).ready(function() {
	$('.select2').select2({theme: 'bootstrap-5'});
})